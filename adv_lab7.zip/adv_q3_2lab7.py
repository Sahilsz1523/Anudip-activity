import math

sqrt_49 = math.sqrt(49)
sine_90 = math.sin(math.radians(90))

print("Square root of 49:", sqrt_49)
print("Sine of 90 degrees:", sine_90)
