from datetime import datetime

now = datetime.now()
hour = now.hour

if hour < 12:
    greeting = "Good Morning"
elif 12 <= hour < 18:
    greeting = "Good Afternoon"
else:
    greeting = "Good Evening"

print(greeting)
