import random as rnd

rand_int = rnd.randint(1, 100)
print("Random integer between 1 and 100:", rand_int)
