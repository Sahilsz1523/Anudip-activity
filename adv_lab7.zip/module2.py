from module1 import add, subtract
from math import pi, log as logarithm
print("Add:", add(10, 5))          
print("Subtract:", subtract(10, 5)) 
radius = 7
area = pi * radius ** 2
print("Area of circle:", area)
print("Natural log of 10:", logarithm(10))
