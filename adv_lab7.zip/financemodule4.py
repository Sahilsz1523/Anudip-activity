import financemodule3

expenses = [100, 50, 75]
income = [1000, 2000]

total_expenses = financemodule3.calculate_expenses(expenses)
total_income = financemodule3.calculate_income(income)
savings = financemodule3.calculate_savings(income, expenses)

print("Expenses:", total_expenses)
print("Income:", total_income)
print("Savings:", savings)
