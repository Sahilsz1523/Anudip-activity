
def calculate_expenses(expenses_list):
    """Calculate total expenses from a list."""
    return sum(expenses_list)

def calculate_income(income_list):
    """Calculate total income from a list."""
    return sum(income_list)

def calculate_savings(income_list, expenses_list):
    """Calculate savings as income minus expenses."""
    total_income = calculate_income(income_list)
    total_expenses = calculate_expenses(expenses_list)
    return total_income - total_expenses
